# Orden de SQL - COMAS

Seleccionar la base correcta de COMAS. Respaldar antes de ejecutar; no se ejecuta ningun script automaticamente. Los historicos se aplican solo si faltan o requieren actualizacion en esta sede. El orden no implica que todos deban ejecutarse de nuevo.

1. 01_saldos_iniciales_sql2008.sql: en la base principal de la API si no existe InventarioSaldoInicial. Si existe la version antigua con FechaFin, se detiene para revisar sus datos.
2. 02_kardex_seis_procedimientos_COMAS.sql: preparado para las definiciones revisadas de COMAS. Comparar y respaldar antes de aplicar; desactiva escrituras directas de Kardex, incluida la nota de credito potencialmente compartida con escritorio. No ejecutado permanentemente en DXNCOMAS2411.
3. Si hacen falta los historicos, ejecutar 03 a 13 por orden: indices/listados, permisos/reportes y mantenimiento. Los scripts 04, 05, 06 y 07 reemplazan procedimientos; comparar la definicion instalada antes de ejecutarlos. 08 y 10–13 crean solamente si faltan.
4. alternativos/parche_facturas.sql es alternativa de 05 para una instalacion existente; no ejecutar 05 y el parche por rutina.

La consulta de reproceso de inventario va incluida en el backend y no necesita instalarse como procedimiento. El acceso a COMAS y COMAS y la configuracion de bases son propios del servidor.
