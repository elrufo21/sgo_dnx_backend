# Build completo COMAS - 24/11/2026

Incluye frontend, backend .NET 7, extension y agente de impresion del build COMAS del 20/11/2026. Conservar appsettings, medios y llaves existentes del servidor.

SQL/kardex/ contiene los seis procedimientos de Kardex y la creacion de saldos iniciales preparados el 20/11/2026. SQL/historicos/ contiene scripts de los builds anteriores para las demas funciones. Son archivos originales para el responsable SQL; no se ejecutan automaticamente ni deben aplicarse todos por rutina. Los seis procedimientos afectan las escrituras de Kardex y uspinsertarNC puede ser compartido con escritorio. La tabla de saldos se crea en la base principal utilizada por la API.

Destino web: http://192.168.18.47:8080
API: http://192.168.18.47:8081/api/v1
El paquete incluye el token del agente de impresion.
