# Actualizacion completa DNX ICA

Web: http://192.168.1.38:8080
API: http://192.168.1.38:8081/api/v1
Base prevista: DXN_ICA

Incluye web, API .NET 7 win-x64, extension y agente de impresion. Respaldar sitios IIS antes de actualizar. Copiar web/ y api/ a sus carpetas respectivas, conservando los appsettings existentes, medios y llaves del servidor. La plantilla en configuration/ es solo para instalaciones nuevas. Para estaciones de trabajo usar extension/ y print-agent/ de esta misma sede.

Los SQL historicos incluidos son solo para revision del responsable de base de datos. Comprobar dependencias y versiones instaladas antes de aplicar cualquier script; no se ha ejecutado SQL. Probar acceso, Pago Varios y la impresion despues de instalar. Este paquete contiene un token del agente; compartir solo con personal autorizado.
