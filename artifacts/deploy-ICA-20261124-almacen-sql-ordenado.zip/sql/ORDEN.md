# Orden de SQL - ICA

Seleccionar la base correcta de ICA. Respaldar antes de ejecutar; no se ejecuta ningun script automaticamente. Los historicos se aplican solo si faltan o requieren actualizacion en esta sede. El orden no implica que todos deban ejecutarse de nuevo.

1. 01_saldos_iniciales_sql2008.sql: en la base principal de la API si no existe InventarioSaldoInicial. Si existe la version antigua con FechaFin, se detiene para revisar sus datos.
2. Kardex ICA: no hay script adaptado y validado para sus seis procedimientos en esta entrega. No copiar el script de COMAS; comparar las definiciones de ICA y preparar su propia version.
3. Si hacen falta los historicos, ejecutar 03 a 13 por orden: indices/listados, permisos/reportes y mantenimiento. Los scripts 04, 05, 06 y 07 reemplazan procedimientos; comparar la definicion instalada antes de ejecutarlos. 08 y 10–13 crean solamente si faltan.
4. alternativos/parche_facturas.sql es alternativa de 05 para una instalacion existente; no ejecutar 05 y el parche por rutina.

La consulta de reproceso de inventario va incluida en el backend y no necesita instalarse como procedimiento. El acceso a ICA y COMAS y la configuracion de bases son propios del servidor.
