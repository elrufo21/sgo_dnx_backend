# Instalacion ICA

Frontend: http://192.168.1.38:8080
API: http://192.168.1.38:8081/api/v1

Contiene frontend, API .NET 7 win-x64, extension y agente. Copiar web/ y api/ a sus destinos conservando el appsettings, medios y llaves de la sede. La plantilla es solo para instalaciones nuevas. El token de impresion del paquete es confidencial.

Los SQL estan ordenados en sql/ORDEN.md. El responsable SQL selecciona y ejecuta solo los necesarios. El build no ejecuta SQL. Almacen conserva los procedimientos de apertura y cierre existentes y la funcion requiere pruebas funcionales antes de uso.
