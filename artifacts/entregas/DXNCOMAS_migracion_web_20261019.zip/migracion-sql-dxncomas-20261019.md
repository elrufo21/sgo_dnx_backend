# Paquete SQL de migración web para DXNCOMAS

Estos scripts preparan en `DXNCOMAS` los objetos requeridos por los flujos que el frontend actual alcanza y llama. La selección sigue la cadena frontend → endpoint → backend → SQL documentada en [el análisis de alcance](analisis-dxncomas-migracion-web-20261018.md); no toma todos los objetos que quedaron en el backend.

Revisado contra ambas bases y el código actual el **19/10/2026**. Los ocho archivos del paquete están adaptados a **SQL Server 2008** y pasaron el analizador TSql100Parser. La ejecución de ensayo fue en SQL Server 16 con compatibilidad 100; no hubo prueba sobre un motor 2008 real. El detalle de pendientes para el pase está en [revisión del pase a COMAS](revision-pase-dxncomas-20261019.md). El paquete no fue aplicado a DXNCOMAS.

## Archivos y orden

Los archivos están en `scripts/sql/dxncomas-20261019/`:

0. `00_compatibilidad_inserts_dxncomas.sql`: explicita las columnas originales en seis procedimientos propios de COMAS. Conserva sus cálculos y valores. Aborta si cambió la definición capturada; puede repetirse si ya está corregida.
1. `01_tablas_dxncomas.sql`: crea `dbo.Indicador` y `dbo.DocumentoVentaCpeWeb`, con sus claves, relaciones e índices. Incluye las 20 columnas de esas dos tablas.
2. `02_columnas_dxncomas.sql`: agrega 14 columnas faltantes a tablas existentes. `NotaPedido.Hora` y `NotaPedido.Almacen` son complementarias; la web comprueba si existen antes de usarlas.
3. `03_procedimientos_dxncomas.sql`: instala **44 procedimientos** de la referencia actual ausentes en COMAS. Incluye ahora `uspListaDocumentosWEB`; ayer no estaba instalado en la referencia.
4. `04_configuracion_inicial_dxncomas.sql`: crea 24 indicadores raíz por compañía, solo si no existen. Toma las renovaciones, días de depósito y credenciales SOL de la propia COMAS. El PFX y los destinatarios quedan pendientes.
5. `05_diagnostico_dxncomas.sql`: solo lectura; informa los objetos/columnas ausentes, configuración, usuarios, estaciones, series e INSERT heredados pendientes.
6. `06_indices_web_opcional.sql`: agrega dos índices de lectura de documentos. Es opcional y no agrega las FK históricas de ICA a COMAS.

Para instalar 00–04 en una transacción y después mostrar el diagnóstico, usar `instalar_paquete_dxncomas.sql` en modo SQLCMD. Desde la carpeta del paquete:

```powershell
sqlcmd -S 'SERVIDOR\INSTANCIA' -E -b -f 65001 -i instalar_paquete_dxncomas.sql
```

Antes de ejecutarlo, respaldar COMAS y revisar los valores iniciales del archivo 04. Los archivos seleccionan DXNCOMAS explícitamente. Se verifican tablas/columnas/índices antes de crear. Para procedimientos se crea un cuerpo vacío únicamente si el objeto no existe y después se usa `ALTER PROCEDURE`, conservando el objeto y sus permisos. Los errores usan `RAISERROR`; las huellas de compatibilidad usan SHA1 por bloques menores de 8000 bytes. No se usa sintaxis posterior a SQL Server 2008 en el paquete. El diagnóstico informa pendientes; no certifica que estén resueltos los nueve contratos excluidos.

## Exclusiones solicitadas

El archivo de procedimientos **no contiene** estos nueve procedimientos que la web llama pero faltan en ambas copias. Conservan la exclusión del paquete anterior; se debe resolver su contrato antes de habilitar las funciones afectadas:

- `uspEliminarCategoria`
- `uspEliminarProducto`
- `uspEliminarProveedor`
- `uspGuardarUnidadMedidaProducto`
- `uspInsertarCategoria`
- `uspInsertarCuentaProveedor`
- `uspInsertarProveedor`
- `uspInsertarUsuario`
- `uspListarComprasweb`

Tampoco instala objetos que solo aparecen en el backend sin consumidor actual, ni crea `BLOQUE`, `DetalleBloque`, `Stock` o `RentaMensual`. `uspCruzeOBS` ya existe en COMAS; su diferencia de definición queda para revisión aparte y no se reemplaza automáticamente.

## Datos y compatibilidad

El paquete no transfiere datos ni configuraciones de ICA. El archivo 04 inserta configuraciones iniciales y copia únicamente valores propios de COMAS dentro de la misma base. No modifica `Compania`, usuarios, asistencia, ventas, cajas, series ni correlativos. Tampoco elimina las columnas históricas de renovación.

Valores iniciales: asistencia exigida (`1`), múltiples cajas desactivado (`0`), captura HTML desactivada (`0`), boleta por lote activada (`1`), descuento `0` y CPE en **beta (`3`)**. Deben revisarse para COMAS. Reejecutar 04 no cambia indicadores existentes; un cambio posterior se hace desde Configuración o mediante un script específico revisado.

Completar PFX real y clave, destinatarios administrativos, SMTP en `EmailSettings`, configuración SUNAT/SIRE, permisos por área, series/correlativos, nombre comercial y almacenamiento. No se conceden permisos automáticamente ni se interpreta el nombre histórico del certificado como su contenido Base64.

El archivo 00 cubre los seis procedimientos antiguos con `INSERT ... VALUES` sin lista de columnas: `ingresarProducto`, `ingresarUsuario`, `InsertarUM`, `uspinsertarNotaB`, `uspInsertarPagoVarios` y `uspinsertarRB`. Se conservan sus definiciones de COMAS; solo se agregan las listas de columnas originales. Esta corrección evita que agregar columnas rompa las inserciones del escritorio.

El paquete se ejecutó dos veces en una base vacía reconstruida desde el esquema de COMAS: pasó la transacción de instalación, la idempotencia, la preservación de configuración y el enlace de los 44 procedimientos mediante `sp_refreshsqlmodule`. La base temporal se eliminó. Esto verifica estructura y compilación; siguen pendientes las pruebas funcionales con datos de ensayo y la resolución de los nueve contratos. Ver la evidencia en `artifacts/analisis-dxncomas-20261019/validacion_paquete.json`.

La compatibilidad de estos archivos no certifica toda la API contra SQL Server 2008: se detectaron consultas directas con funciones posteriores a esa versión, por ejemplo `CONCAT` en el envío de correo y `TRY_CONVERT` en la búsqueda de documentos. Deben adaptarse y probarse antes de poner toda la web contra un motor 2008. Ver el detalle de esta limitación en el informe del pase.
